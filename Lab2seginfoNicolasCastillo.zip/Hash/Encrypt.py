import time

from Functions.commonfunctions import Readtextfromfile, Writetextonfile
from Functions.lock import putallKeys

finalstring = putallKeys(Readtextfromfile("mensajedeentrada.txt"))
Writetextonfile("mensajeseguro.txt", finalstring)
print("The hashing is done, check the file 'mensajeseguro.txt' please.")
time.sleep(5)
