import hashlib


def lastkey(text):
    text = text.split("#")
    key = text[0]
    text = text[1::]
    finaltext = ""
    try:
        for x in text:
            finaltext += "{}".format(chr(int(x, 16)))
        hash_object = hashlib.md5(finaltext.encode())
        if hash_object.hexdigest() == key:
            return True, finaltext
        else:
            return False
    except:
        return False


def secondkey(text):
    text = text.split("\n")
    key = text[0]
    text = text[1].split("|")
    finaltext = ""
    try:
        for x in text:
            finaltext += str(chr(int(x)))
        hash_object = hashlib.sha1(finaltext.encode())
        if hash_object.hexdigest() == key:
            return True, finaltext
        else:
            return False
    except:
        return False


def firstkey(text):
    try:
        text = text.split("\n")
        key = text[len(text) - 1]
        text = text[:-1]
        finaltext = ""
        for x in text:
            finaltext += "{}\n".format(x)
        finaltext = finaltext[:-1]
        hash_object = hashlib.sha256(finaltext.encode())
        if hash_object.hexdigest() == key:
            return True, finaltext
        else:
            return False
    except:
        return False


def checksum(text):
    first = firstkey(text)
    if first:
        second = secondkey(first[1])
        if second:
            last = lastkey(second[1])
            if last:
                print("The file is alive, and the checksums is correct.")
                return True, last[1]
            else:
                print("The File is corrupted")
        else:
            print("The File is corrupted")
    else:
        print("The File is corrupted")
    return False
