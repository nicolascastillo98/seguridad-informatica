import hashlib


def putFirstKey(text):
    """Texto en primera fase a ser encriptado, se toma su estado inicial y se da un hash de tipo md5
    luego se transforma cada caracter a su orden ASCII para luego calcularle su valor HexaDecimal, siendo separado cada
    caracter por #, es el metodo mas profundo de la cadena de cifrado, pero a la vez es muy evidente, por eso se utiliza
    el resto de los cifrados"""
    hash_object = hashlib.md5(text.encode())
    finalstring = str(hash_object.hexdigest()) + "#"
    for x in text:
        finalstring += "{}#".format(hex(ord(x)))
    return finalstring[:-1]


def putSecondKey(text):
    """Texto a separar por un salto de linea con un Hash Sha1, y además cifrar cada letra por el ordenamiento
    ASCII separando cada letra por una | para ser reconocido mas tarde, a modo de ocultar la llave anterior"""
    secondhash = hashlib.sha1(text.encode()).hexdigest() + "\n"
    secondline = ""
    for x in text:
        secondline += "{}|".format(ord(x))
    return secondhash + secondline[:-1]


def putLastKey(text):
    """Texto a darle un Hash tipo Sha256 simple, separado por un salto de linea
    Su proposito es asegurar el estado del texto en una primera fase y además de reconocer al Hash Sha1 dentro de su hashing"""
    return "{}\n{}".format(text, hashlib.sha256(text.encode()).hexdigest())


def putallKeys(text):
    return putLastKey(putSecondKey(putFirstKey(text)))
