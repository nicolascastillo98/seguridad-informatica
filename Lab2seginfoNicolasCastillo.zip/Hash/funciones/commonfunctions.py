def Readtextfromfile(filename):
    file = open(filename, "r",encoding="UTF-8")
    r = file.read()
    file.close()
    return r


def Writetextonfile(filename, text):
    file = open(filename, "w",encoding="UTF-8")
    file.write(text)
    file.close()
