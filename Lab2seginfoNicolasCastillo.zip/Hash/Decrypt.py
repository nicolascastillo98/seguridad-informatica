#Laboratorio 2 Seguridad Informática
#Profesor Manuel Alba
#Alumno Nicolás Castillo.B


import time

from Functions.commonfunctions import Readtextfromfile
from Functions.unlock import checksum

check = checksum(Readtextfromfile("mensajeseguro.txt"))
if check:
    print(check[1])
time.sleep(5)
